public class ConfigurationVariables{
    public ulong ERRMAX;
    public ulong MAXLINE;
    public long MAXINT;
}
