public struct Error{
    public TextPosition Position;
    public long ErrorCode;
    public string? SpecificErrorDescription;
}
