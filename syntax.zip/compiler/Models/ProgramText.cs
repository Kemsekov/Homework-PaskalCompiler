public class ProgramText{
    public ProgramText(string[] lines)
    {
        Lines = lines;
    }
    public string[] Lines{get;}
}