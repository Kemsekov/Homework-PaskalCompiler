
run

```
dotnet run input.pas
```
